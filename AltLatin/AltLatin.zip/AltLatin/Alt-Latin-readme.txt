Alt-Latin keyboard layout for OS X 10.2 and higher


This is an enlarged version of U.S. Extended keyboard layout coming with OS X 10.2 and 10.3. It supports a larger number of accented letters.

As Alt-Latin is treated to be belonging to Roman script, you can use it also as the default keyobard layout for MacRoman encoding. In other words, if you use it, you don't need switching from U.S. to U.S. Extended any more.

Though Alt-Latin works with any OS X application, non-Unicode application won't recognise a character not supported by MacRoman encoding.



To install AltLatin.bundle,

1. Put AltLatin.bundle in

	/Users/YourAccount/Library/Keyboard Layouts

If you don't have "Keyboard Layouts" folder, just create it.

2. Open System Preferences => International => Input Menu, check Alt-Latin and close System Preferences.



Then you should be able to choose Alt-Latin from Flag menu in Menubar. However this may not work at times. If Alt-Latin is not recognized,

1. Trash

	/Library/Caches/com.apple.IntlDataCache.kbdx.501
	(the number 501 may be different. It's you user ID.)

2. Log out and log back in.



DISCLAIMER: Absolutely no warranty though a buggy keyboard layout file would be simply ignored and would not cause a problem -- I hope ;-)


2004 Kino

