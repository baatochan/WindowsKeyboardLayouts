

*** Alt-Latin keyboard layout for Windows 2000/XP ***


This keyboard layout is a clone of Mac OS X Alt-Latin keyboard layout, created with Microsoft Keyboard Layout Creator.
<http://www.microsoft.com/globaldev/tools/msklc.mspx>

You can customize or correct it by modifying the source file "alt_latin.klc" and regenerate the keyboard layout package.


Alt-Latin keyboard layout is based on Mac OS X 10.2 U.S. Extended keyboard layout, but heavily modified by me. For basic characters, the disposition is closer to U.S. keyboard layout.


To see the keylayout, use Microsoft Visual Keyboard.
<http://office.microsoft.com/downloads/2000/viskeyboard.aspx>



To install Alt-Latin keyboard layout, double click on AltLatin.msi inside AltLatin folder.


To enable Alt-Latin keyboard layout.

 1. Open Start => Settings => Control Panel => Regional Options (Keyboard in XP?);

 2. In Input Locale tab, click on Add button;

 3. In the Keyboard Layout/IME select Alt-Latin from Pull-down menu;

 4. Click Ok then Apply and OK on the Regional Options (Keyboard in XP?) panel.



To deinstall Alt-Latin keyboard layout,

 1. Remove/disable Alt-Latin keyboard layout in Regional Options / Keyboard Control panel;

 2. Double click on AltLatin.msi inside AltLatin folder;

 3. In Setup Wizard dialog box, make sure that "Remove Alt-Latin" is selected and click on Finish.



Absolutely free, absolutely no guarantee.


23 June 2004, Kino

